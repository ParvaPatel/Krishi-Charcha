import React from 'react'
import './Services.css';

export default function Services() {
    return (
        <div className="fun">
            <br /><br /><br /><br />
            <div className="main">
                <div className="write">
                    <h1 className="Heads">
                        Solutions by Your Company
        </h1>
                    <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                        industry's
                        standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                        make
                        a type specimen book. It has survived not only five centuries, but also the leap into electronic
                        typesetting,
                        remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets
                        containing
                        Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including
                        versions
                        of Lorem Ipsum.
        </p>
                </div>
                <div className="tablediv">
                        <div className="Box"><img className="img1" src="images\advice.png" /><p className="desc">Expert Advice</p></div>
                        <div className="Box"><img className="img1" src="images\quality.png" /><p className="desc">Quality</p></div>
                        <div className="Box"><img className="img3" src="images\customer-service.png" /><p className="desc">Customer Care</p></div>
                        <div className="Box"><img className="img4" src="images\convi.png"  /><p  className="desc">Convinience</p></div>
                        <div className="Box"><img className="img5" src="images\download.png"  /><p  className="desc">Agronomy</p></div>
                        <div className="Box"><img className="img6" src="images\download (1).png" /><p  className="desc">Agri Inputs</p></div>
                        <div className="Box"><img className="img7" src="images\data-analytics-2-536732.png"  /><p  className="desc">Technology</p></div>
                        <div className="Box"><img className="img8" src="images\agri_inp.png" /><p  className="desc">Analysis</p></div>


                    </div>
                </div>
        </div>
    )
}
