import './Blogs.css';

const Blogs = () => {
   

    
    return (
        <>
            <br /><br /><br /><br />

            <div className="Major" >
                <div className="f">
                    <a href="#" class="faBlog fa fa-facebook"></a>
                    <a href="#" class="faBlog fa fa-twitter"></a>
                    <a href="#" class="faBlog fa fa-google"></a>
                    <a href="#" class="faBlog fa fa-linkedin"></a>

                </div>
                <div className="s">
                    <img className="blogImg" src="/images/blog1.jpg" alt="image" />
                </div>
                <div className="t">
                    <h1>Bluberry Salad</h1>
        Here’s a roundup of a handful of barberry recipes. This fruit features most commonly in Persian recipes, be it
        sprinkled in a rice dish or as the main flavor in sherbet. If interested in cooking with barberries, consider
        using recipes calling for cranberries or pomegranate seeds and substituting this small, tangy berry in its
        place.
    </div>
            </div>


        </>
    );
}

export default Blogs;